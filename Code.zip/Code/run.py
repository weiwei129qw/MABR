from gpt_utils import call_ChatGPT1, call_ChatGPT2, call_ChatGPT3



#读数据
dataset = ["""when editing a .reg file , 
           you have to press the ** del ** key twice to delete a key . 
           this is the same with ** backspace ** . phofnewline phofnewline also , 
           when you highlight text , the amount highlighted is half the position of the cursor . phofnewline phofnewline for example , 
           trying to highlight idtid40 _i idtid0 am using atom to edit idtid40 text_ idtid0 , would only highlight idtid40 _i idtid0 am using idtid40 at_ idtid0 . phofnewline phofnewline note that typed text after opening the file and before saving is n't affected by this issue . phofnewline """]



for bug_report in dataset:
    j = 0
    is_prefect, suggest = call_ChatGPT1(bug_report, model="gpt-3.5-turbo")
    #with open("path","w") as f:
    #    f.write(suggest)
    if is_prefect == False:
        for i in range(5):
            bug_report_modify = call_ChatGPT2(bug_report, suggest, model="gpt-3.5-turbo")

            is_prefect_post, suggest_post = call_ChatGPT3(bug_report_modify, model="gpt-3.5-turbo")
            if is_prefect_post == True:
                break
            else:
                suggest = suggest_post
                bug_report = bug_report_modify
    else:
        bug_report_modify = bug_report
    j += 1
    #with open("path","w") as f:
     #   f.write(bug_report_modify)
    print(bug_report_modify)

 