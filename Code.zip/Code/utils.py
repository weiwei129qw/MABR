import json
import re

import openai

openai.api_key = "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"


def call_ChatGPT1(bug_report, model="gpt-3.5-turbo"):
    """调用ChatGPT"""
    response = openai.ChatCompletion.create(
        model=model,
        messages=[
            {"role": "assistant", "conent": """I hope you can serve as an analysis expert in our team. Analyze the report content from five aspects: ID, title, observation behavior, expected behavior, and reproduction steps, determine whether it is complete, 
                    and indicate which information is missing or unclear. 
                    Provide specific suggestions for the missing parts and assist experts in supplementing the missing content. 
                    For example, pointing out key information or possible phenomena that should be paid attention to to to help complete the process."""},
            {"role": "user", "conent": "bug_report"},
            {"role": "system", "conent": """In this collaborative team, analysis experts, completion experts, and quality assessment experts are each responsible for different tasks and work closely together to complete high-quality defect reports. Regular communication and feedback are required among team members to ensure consistency and accuracy of the report content during the completion process.
The bug report should include the following five aspects:
1. ID: The unique identifier for the bug report.
2. Title: A brief description of the bug.
3. Observational Behavior (OB): Describe the current system's behavior, errors, or unexpected outputs. Vague statements such as' the system is not functioning 'should be avoided.
4. Expected Behavior (EB): Clearly describe the expected behavior that the system should have. Use expressions such as "should..." and "expect..." to avoid providing solutions.
5. Reproduction steps (SR): List in detail the steps that can reproduce the defect, using clear expressions such as "copy", "perform the following steps", etc.
If any part of the bug report (such as OB, EB, SR) lacks details, the expert team needs to collaborate to complete the missing content and ensure that the final output report is complete, logical, and clear, so that developers can effectively repair the defect based on the report."""}
                    ]
    )
    print(response) #return is_prefect, suggest
    # 解析数据{"response":"True"}从返回的结果中拿出来你需要的格式
    # if response["choices"][0]["finish_reason"] == "length":
    #     print("====The output exceeds the length limit====")
    #     return 2, None
    # elif response["choices"][0]["finish_reason"] == "stop":
    #     # response["origin"] = {}
    #     # response["origin"]["input_prompt"] = llm_prompt
    #     # response["origin"]["input_content"] = input_report.split('</BUG REPORT>')[0].strip()
    #     response = response["choices"][0]["message"]["content"]
    #     response = response.encode('utf-8', 'ignore').decode("utf-8")  # 去除非utf8字符
    #     return 0, response
    # else:
    #     print("====invoke openai api error====")
    #     return 3, None


def call_ChatGPT2(bug_report, suggest, model="gpt-3.5-turbo"):
    """调用ChatGPT"""
    response = openai.ChatCompletion.create(
        model=model,
        messages=[{"role": "assistant", "conent": """Your role is a senior software engineer, skilled in completing defect reports. 
                   You will receive reports from analysis experts or feedback from evaluation experts. Your job is divided into two parts:
1. Complete the report based on the advice of the analysis expert: 
                   If you receive an incomplete defect report and the analysis expert's completion suggestion, 
                   you need to infer and fill in the missing information based on the context. 
                   Ensure that the description of observed behavior (OB), expected behavior (EB), and reproducing steps (SR) in the report is clear and complete. 
                   According to the feedback from the evaluation experts, if you receive feedback from them, 
                   you need to repair or improve the content of the report based on their suggestions. 
                   Ensure that any modifications made do not introduce new errors or unclear statements, and avoid negative impacts on the quality of the report.
Attention: Please ensure that the defect report you provide is concise, clear, and complete in information. There is no need to explain the content you have completed, just make sure that the report meets high-quality standards and can provide developers with sufficient repair guidance."""},
                {"role": "user", "conent": "bug_report"},
                {"role": "assistant", "conent": "suggest"},
            {"role": "system", "conent": """In this collaborative team, analysis experts, completion experts, and quality assessment experts are each responsible for different tasks and work closely together to complete high-quality defect reports. Regular communication and feedback are required among team members to ensure consistency and accuracy of the report content during the completion process.
The bug report should include the following five aspects:
1. ID: The unique identifier for the bug report.
2. Title: A brief description of the bug.
3. Observational Behavior (OB): Describe the current system's behavior, errors, or unexpected outputs. Vague statements such as' the system is not functioning 'should be avoided.
4. Expected Behavior (EB): Clearly describe the expected behavior that the system should have. Use expressions such as "should..." and "expect..." to avoid providing solutions.
5. Reproduction steps (SR): List in detail the steps that can reproduce the defect, using clear expressions such as "copy", "perform the following steps", etc.
If any part of the bug report (such as OB, EB, SR) lacks details, the expert team needs to collaborate to complete the missing content and ensure that the final output report is complete, logical, and clear, so that developers can effectively repair the defect based on the report."""}
                    
                    ]
    )

    

def call_ChatGPT3(bug_report, model="gpt-3.5-turbo"):
    """调用ChatGPT"""
    response = openai.ChatCompletion.create(
       model=model,
       messages=[{"role": "assistant", "conent": """As a quality assessment expert, 
                  you will receive a report from the completion expert. Your task is to conduct a final quality review of the report, 
                  ensuring that its structure is reasonable, its logic is clear, and its language is accurate and error free. Your responsibilities include the following:
1. Content review: Check the logic and clarity of the statements in the report to ensure accurate and understandable information expression.
2. Structural review: Ensure that the structure of the report is unified and appropriate, and check for any redundant, ambiguous, or unclear statements.
3. Conclusion and Suggestions: Based on the review results, it is recommended whether the report needs to be rewritten or adjusted. Ensure that the report meets high-quality standards and provide a conclusion: 'Defect report quality inspection passed' or 'failed'.
Attention: Quality assessment experts do not participate in content supplementation, 
                  but focus on the final review of report quality to ensure that the report can provide developers with clear and accurate repair guidance."""},
                {"role": "assistant", "conent": "bug_report"},
            {"role": "system", "conent": """In this collaborative team, analysis experts, completion experts, and quality assessment experts are each responsible for different tasks and work closely together to complete high-quality defect reports. Regular communication and feedback are required among team members to ensure consistency and accuracy of the report content during the completion process.
The bug report should include the following five aspects:
1. ID: The unique identifier for the bug report.
2. Title: A brief description of the bug.
3. Observational Behavior (OB): Describe the current system's behavior, errors, or unexpected outputs. Vague statements such as' the system is not functioning 'should be avoided.
4. Expected Behavior (EB): Clearly describe the expected behavior that the system should have. Use expressions such as "should..." and "expect..." to avoid providing solutions.
5. Reproduction steps (SR): List in detail the steps that can reproduce the defect, using clear expressions such as "copy", "perform the following steps", etc.
If any part of the bug report (such as OB, EB, SR) lacks details, the expert team needs to collaborate to complete the missing content and ensure that the final output report is complete, logical, and clear, so that developers can effectively repair the defect based on the report."""}
                    
                ]
    )